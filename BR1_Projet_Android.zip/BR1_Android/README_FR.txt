BR1 — PROJET ANDROID (VERSION 1.0)
==========================================

Compatibilité visée : Android 6.0 ou supérieur, dont Android 11.
Application hors ligne : gestion manuelle de quotas virtuels.

IMPORTANT
---------
Ce projet ne crée pas de connexion Internet et ne génère pas de mégas Africell.
Les quotas 500 Mo, 1 Go, 2 Go, 5 Go et 10 Go sont des compteurs personnels.
La consommation doit être saisie manuellement. Les données sont conservées
localement sur le téléphone dans le stockage du WebView.

CONTENU
-------
- app/ : code de l'application Android.
- app/src/main/assets/index.html : interface BR1.
- MainActivity.java : ouvre l'interface dans une WebView Android.

COMMENT OBTENIR L'APK
---------------------
Ce dossier est un projet source Android, pas encore un fichier APK compilé.
Pour le compiler, il faut Android Studio avec le SDK Android installé :

1. Décompresser ce ZIP sur un ordinateur.
2. Ouvrir Android Studio.
3. Choisir "Open" et sélectionner le dossier REBELL_NET_Android.
4. Attendre la synchronisation Gradle et l'installation des composants SDK.
5. Choisir Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Android Studio affichera le lien vers app-debug.apk.

L'APK debug généré pourra ensuite être transféré sur l'itel A27 et installé.
